#!/usr/bin/python
# ADXL345 Python example
#
# author:  Jonathan Williamson
# license: BSD, see LICENSE.txt included in this package
#
# This is an example to show you how to the Grove +-16g Accelerometer
# http://www.seeedstudio.com/depot/Grove-3Axis-Digital-Accelerometer16g-p-1156.html

from adxl345 import ADXL345
import time
import math
import os
os.chdir("/home/pi/Dexter/GrovePi/Software/Python/grove_accelerometer_16g")
adxl345 = ADXL345()

print("ADXL345 on address 0x%x:" % (adxl345.address))
vCounter = 0

while True:
        value_list = []
        for i in range(0,500):
                try:
                        axes = adxl345.getAxes(True)
                except:
                        pass
                xValue = axes['x']
                yValue = axes['y']
                zValue = axes['z']
		os.system('clear')
	 	print("xValue ", xValue)
		print("yValue ", yValue)
		print("zValue ", zValue)
		print(" ")
                time.sleep(.01)
                axes = adxl345.getAxes(True)
                xDiff = abs(xValue-axes['x'])
                yDiff = abs(yValue-axes['y'])
                zDiff = abs(zValue-axes['z'])
                value_list.append(max(xDiff,yDiff,zDiff))
        second_avg = sum(value_list)/len(value_list)
        #print(second_avg)
        f = open("/ramdisk/vibration.value", "w")
        f.write(str(second_avg*100))
        f.close()

